"""
Advanced Phonebook GUI client (PyQt6)
Run `python app.py`; configure server URL in the login dialog.
"""
import base64
import csv
import json
import sys
from datetime import date, datetime
from pathlib import Path

import requests
from openpyxl import Workbook, load_workbook
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QPixmap
from PyQt6.QtWidgets import (
    QApplication, QComboBox, QDialog, QDialogButtonBox, QFileDialog,
    QFormLayout, QHBoxLayout, QLabel, QLineEdit, QMainWindow, QMessageBox,
    QPushButton, QTableWidget, QTableWidgetItem, QTextEdit, QVBoxLayout,
    QWidget, QAbstractItemView, QInputDialog
)

APP_DIR = Path(__file__).resolve().parent
CATEGORIES = ["عمومی", "خانواده", "دوستان", "کار", "مشتری", "سایر"]


class Api:
    def __init__(self):
        self.base = "http://127.0.0.1:8765"
        self.token = None
        self.username = None
        self.role = "user"
        self.session = requests.Session()

    def request(self, method, path, **kwargs):
        headers = kwargs.pop("headers", {})
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        response = self.session.request(method, self.base + path, headers=headers, timeout=20, **kwargs)
        try:
            data = response.json()
        except ValueError:
            data = {}
        if not response.ok:
            raise RuntimeError(data.get("error", f"خطای سرور ({response.status_code})"))
        return data

    def login(self, base, username, password):
        self.base = base.rstrip("/")
        data = self.request("POST", "/api/login", json={"username": username, "password": password})
        self.token = data["token"]
        self.username = data["username"]
        self.role = data["role"]
        return data

    def contacts(self, query="", category="همه"):
        from urllib.parse import urlencode
        return self.request("GET", "/api/contacts?" + urlencode({"q": query, "category": category}))

    def contact(self, cid):
        return self.request("GET", f"/api/contacts/{cid}")

    def add(self, data):
        return self.request("POST", "/api/contacts", json=data)

    def update(self, cid, data):
        return self.request("PUT", f"/api/contacts/{cid}", json=data)

    def delete(self, cid):
        return self.request("DELETE", f"/api/contacts/{cid}")

    def reminders(self):
        return self.request("GET", "/api/reminders")

    def backup(self):
        return self.request("POST", "/api/admin/backup")

    def change_password(self, old_password, new_password):
        return self.request("POST", "/api/account/password", json={
            "old_password": old_password, "new_password": new_password
        })

    def users(self):
        return self.request("GET", "/api/admin/users")

    def create_user(self, username, password, role="user"):
        return self.request("POST", "/api/admin/users", json={
            "username": username, "password": password, "role": role
        })

    def set_user_active(self, user_id, active):
        return self.request("PATCH", f"/api/admin/users/{user_id}", json={"is_active": active})

    def audit(self):
        return self.request("GET", "/api/admin/audit")

    def logout(self):
        return self.request("POST", "/api/logout")


class LoginDialog(QDialog):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("ورود به دفترچه تلفن")
        self.setMinimumWidth(430)
        self.server = QLineEdit("http://127.0.0.1:8765")
        self.username = QLineEdit("admin")
        self.password = QLineEdit()
        self.password.setEchoMode(QLineEdit.EchoMode.Password)
        form = QFormLayout()
        form.addRow("آدرس سرور", self.server)
        form.addRow("نام کاربری", self.username)
        form.addRow("رمز عبور", self.password)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("ابتدا سرور را روی رایانه میزبان اجرا کنید."))
        layout.addLayout(form)
        layout.addWidget(buttons)


class ContactDialog(QDialog):
    def __init__(self, parent=None, contact=None):
        super().__init__(parent)
        self.contact = contact
        self.setWindowTitle("ویرایش مخاطب" if contact else "افزودن مخاطب")
        self.resize(560, 650)
        self.name = QLineEdit()
        self.phones = QTextEdit()
        self.phones.setPlaceholderText("هر خط یک شماره؛ قالب: شماره | برچسب\nمثال: 09123456789 | موبایل")
        self.phones.setMaximumHeight(95)
        self.email = QLineEdit()
        self.company = QLineEdit()
        self.job = QLineEdit()
        self.address = QLineEdit()
        self.category = QComboBox()
        self.category.addItems(CATEGORIES)
        self.birthday = QLineEdit()
        self.birthday.setPlaceholderText("YYYY-MM-DD")
        self.notes = QTextEdit()
        self.photo_path = ""
        self.photo_label = QLabel("بدون عکس")
        self.photo_label.setMinimumHeight(70)
        self.photo_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.photo_button = QPushButton("انتخاب عکس…")
        self.photo_button.clicked.connect(self.choose_photo)

        form = QFormLayout()
        form.addRow("نام *", self.name)
        form.addRow("شماره‌ها *", self.phones)
        form.addRow("ایمیل", self.email)
        form.addRow("شرکت", self.company)
        form.addRow("عنوان شغلی", self.job)
        form.addRow("آدرس", self.address)
        form.addRow("دسته‌بندی", self.category)
        form.addRow("تاریخ تولد", self.birthday)
        form.addRow("یادداشت", self.notes)
        form.addRow("عکس", self.photo_button)
        form.addRow("", self.photo_label)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.validate)
        buttons.rejected.connect(self.reject)
        layout = QVBoxLayout(self)
        layout.addLayout(form)
        layout.addWidget(buttons)

        self.photo_b64 = ""
        if contact:
            self.name.setText(contact.get("name", ""))
            self.phones.setPlainText("\n".join(f'{p["phone"]} | {p.get("label", "موبایل")}' for p in contact.get("phones", [])))
            self.email.setText(contact.get("email", ""))
            self.company.setText(contact.get("company", ""))
            self.job.setText(contact.get("job_title", ""))
            self.address.setText(contact.get("address", ""))
            self.category.setCurrentText(contact.get("category", "عمومی"))
            self.birthday.setText(contact.get("birthday", ""))
            self.notes.setPlainText(contact.get("notes", ""))
            self.photo_b64 = contact.get("photo_b64", "")
            self.show_photo()

    def choose_photo(self):
        path, _ = QFileDialog.getOpenFileName(self, "انتخاب عکس", "", "Images (*.png *.jpg *.jpeg *.bmp *.webp)")
        if not path:
            return
        try:
            raw = Path(path).read_bytes()
            if len(raw) > 3_500_000:
                QMessageBox.warning(self, "عکس بزرگ است", "لطفاً عکسی کوچک‌تر از ۳٫۵ مگابایت انتخاب کنید.")
                return
            self.photo_b64 = base64.b64encode(raw).decode("ascii")
            self.show_photo(raw)
        except OSError as exc:
            QMessageBox.warning(self, "خطا", str(exc))

    def show_photo(self, raw=None):
        if raw is None and self.photo_b64:
            try:
                raw = base64.b64decode(self.photo_b64)
            except ValueError:
                raw = None
        if raw:
            pix = QPixmap()
            if pix.loadFromData(raw):
                self.photo_label.setPixmap(pix.scaled(120, 90, Qt.AspectRatioMode.KeepAspectRatio,
                                                      Qt.TransformationMode.SmoothTransformation))
                return
        self.photo_label.setText("بدون عکس")

    def validate(self):
        name = self.name.text().strip()
        if not name:
            QMessageBox.warning(self, "ورودی نامعتبر", "نام الزامی است.")
            return
        birthday = self.birthday.text().strip()
        if birthday:
            try:
                datetime.strptime(birthday, "%Y-%m-%d")
            except ValueError:
                QMessageBox.warning(self, "تاریخ نامعتبر", "تاریخ را به صورت YYYY-MM-DD وارد کنید.")
                return
        if not self.phones.toPlainText().strip():
            QMessageBox.warning(self, "شماره لازم است", "حداقل یک شماره وارد کنید.")
            return
        self.accept()

    def values(self):
        phones = []
        for line in self.phones.toPlainText().splitlines():
            line = line.strip()
            if not line:
                continue
            if "|" in line:
                number, label = line.split("|", 1)
            else:
                number, label = line, "موبایل"
            phones.append({"phone": number.strip(), "label": label.strip() or "موبایل"})
        return {
            "name": self.name.text().strip(), "phones": phones,
            "email": self.email.text().strip(), "company": self.company.text().strip(),
            "job_title": self.job.text().strip(), "address": self.address.text().strip(),
            "category": self.category.currentText(), "birthday": self.birthday.text().strip(),
            "notes": self.notes.toPlainText().strip(), "photo_b64": self.photo_b64
        }


class MainWindow(QMainWindow):
    def __init__(self, api):
        super().__init__()
        self.api = api
        self.setWindowTitle(f"دفترچه تلفن پیشرفته — {api.username}")
        self.resize(1150, 720)
        self.search = QLineEdit()
        self.search.setPlaceholderText("جست‌وجو: نام، شماره، ایمیل، شرکت یا یادداشت…")
        self.search.textChanged.connect(self.refresh)
        self.category = QComboBox()
        self.category.addItems(["همه"] + CATEGORIES)
        self.category.currentTextChanged.connect(self.refresh)
        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(["نام", "شماره‌ها", "شرکت", "ایمیل", "دسته‌بندی", "تولد"])
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setAlternatingRowColors(True)
        self.table.verticalHeader().setVisible(False)
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.doubleClicked.connect(lambda *_: self.edit_contact())

        add = QPushButton("＋ افزودن")
        edit = QPushButton("ویرایش")
        delete = QPushButton("حذف")
        reminders = QPushButton("یادآوری‌ها")
        import_btn = QPushButton("ورود فایل")
        export_btn = QPushButton("خروجی فایل")
        backup_btn = QPushButton("پشتیبان‌گیری")
        password_btn = QPushButton("تغییر رمز")
        theme_btn = QPushButton("تغییر تم")
        users_btn = QPushButton("مدیریت کاربران")
        audit_btn = QPushButton("گزارش فعالیت")
        logout_btn = QPushButton("خروج")
        add.clicked.connect(self.add_contact)
        edit.clicked.connect(self.edit_contact)
        delete.clicked.connect(self.delete_contact)
        reminders.clicked.connect(self.show_reminders)
        import_btn.clicked.connect(self.import_file)
        export_btn.clicked.connect(self.export_file)
        backup_btn.clicked.connect(self.backup)
        password_btn.clicked.connect(self.change_password)
        theme_btn.clicked.connect(self.toggle_theme)
        users_btn.clicked.connect(self.manage_users)
        audit_btn.clicked.connect(self.show_audit)
        logout_btn.clicked.connect(self.logout)
        self.backup_btn = backup_btn
        self.users_btn = users_btn
        if api.role != "admin":
            backup_btn.setEnabled(False)
            users_btn.setEnabled(False)
            audit_btn.setEnabled(False)
        self.dark_theme = False

        toolbar = QHBoxLayout()
        for widget in (add, edit, delete, reminders, import_btn, export_btn, backup_btn, users_btn, audit_btn, password_btn, theme_btn, logout_btn):
            toolbar.addWidget(widget)
        filter_row = QHBoxLayout()
        filter_row.addWidget(QLabel("فیلتر دسته‌بندی"))
        filter_row.addWidget(self.category)
        filter_row.addStretch()
        self.status = QLabel()
        root = QWidget()
        layout = QVBoxLayout(root)
        layout.addWidget(self.search)
        layout.addLayout(filter_row)
        layout.addLayout(toolbar)
        layout.addWidget(self.table, 1)
        layout.addWidget(self.status)
        self.setCentralWidget(root)
        self.apply_theme()
        self.refresh()
        self.check_reminders_on_start()

    def apply_theme(self):
        if self.dark_theme:
            self.setStyleSheet("""
                QWidget { background:#171a21; color:#e9edf5; font-size:13px; }
                QLineEdit,QComboBox,QTextEdit,QTableWidget { background:#222733; border:1px solid #3a4252; border-radius:7px; padding:7px; selection-background-color:#4469a8; }
                QHeaderView::section { background:#252c39; padding:9px; border:0; font-weight:600; }
                QPushButton { background:#293244; border:1px solid #414c60; border-radius:7px; padding:8px 10px; }
                QPushButton:hover { background:#37465f; }
                QTableWidget::item { padding:6px; }
                QTableWidget::item:alternate { background:#1d222d; }
            """)
        else:
            self.setStyleSheet("""
                QWidget { background:#f5f7fb; color:#202938; font-size:13px; }
                QLineEdit,QComboBox,QTextEdit,QTableWidget { background:#ffffff; border:1px solid #d9e0eb; border-radius:7px; padding:7px; selection-background-color:#dce9ff; selection-color:#17233b; }
                QHeaderView::section { background:#edf1f7; padding:9px; border:0; font-weight:600; }
                QPushButton { background:#ffffff; border:1px solid #d5dce7; border-radius:7px; padding:8px 10px; }
                QPushButton:hover { background:#eaf0f8; }
                QTableWidget::item { padding:6px; }
                QTableWidget::item:alternate { background:#f7f9fc; }
            """)

    def toggle_theme(self):
        self.dark_theme = not self.dark_theme
        self.apply_theme()

    def change_password(self):
        old_password, ok = QInputDialog.getText(self, "تغییر رمز", "رمز فعلی:", QLineEdit.EchoMode.Password)
        if not ok:
            return
        new_password, ok = QInputDialog.getText(self, "تغییر رمز", "رمز جدید (حداقل ۱۲ نویسه):", QLineEdit.EchoMode.Password)
        if not ok:
            return
        confirm, ok = QInputDialog.getText(self, "تغییر رمز", "تکرار رمز جدید:", QLineEdit.EchoMode.Password)
        if not ok:
            return
        if new_password != confirm:
            QMessageBox.warning(self, "رمز نامطابق", "رمزهای جدید یکسان نیستند.")
            return
        try:
            self.api.change_password(old_password, new_password)
            self.api.token = None
            QMessageBox.information(self, "رمز تغییر کرد", "برای اعمال تغییرات باید دوباره وارد شوید. برنامه بسته می‌شود.")
            self.close()
            QApplication.quit()
        except Exception as exc:
            QMessageBox.warning(self, "خطا", str(exc))

    def manage_users(self):
        if self.api.role != "admin":
            QMessageBox.warning(self, "دسترسی محدود", "این بخش فقط برای مدیر فعال است.")
            return
        try:
            users = self.api.users()
            lines = [f"{u['id']} | {u['username']} | {u['role']} | {'فعال' if u['is_active'] else 'غیرفعال'}" for u in users]
            QMessageBox.information(self, "کاربران", "\n".join(lines) if lines else "کاربری وجود ندارد.")
            action, ok = QInputDialog.getItem(self, "مدیریت کاربران", "عملیات:", ["ایجاد کاربر", "فعال/غیرفعال کردن کاربر"], 0, False)
            if not ok:
                return
            if action == "ایجاد کاربر":
                username, ok = QInputDialog.getText(self, "کاربر جدید", "نام کاربری (۳ تا ۴۰ نویسه):")
                if not ok:
                    return
                password, ok = QInputDialog.getText(self, "کاربر جدید", "رمز عبور (حداقل ۱۲ نویسه):", QLineEdit.EchoMode.Password)
                if not ok:
                    return
                role, ok = QInputDialog.getItem(self, "نقش کاربر", "نقش:", ["user", "admin"], 0, False)
                if not ok:
                    return
                self.api.create_user(username.strip(), password, role)
                QMessageBox.information(self, "انجام شد", "کاربر ایجاد شد.")
            else:
                candidates = [u for u in users if u['username'] != self.api.username]
                if not candidates:
                    candidates = users
                labels = [f"{u['id']} - {u['username']} ({'فعال' if u['is_active'] else 'غیرفعال'})" for u in candidates]
                label, ok = QInputDialog.getItem(self, "انتخاب کاربر", "کاربر:", labels, 0, False)
                if not ok:
                    return
                user = candidates[labels.index(label)]
                self.api.set_user_active(user['id'], not bool(user['is_active']))
                QMessageBox.information(self, "انجام شد", "وضعیت کاربر به‌روزرسانی شد.")
        except Exception as exc:
            QMessageBox.warning(self, "خطا", str(exc))

    def show_audit(self):
        if self.api.role != "admin":
            return
        try:
            rows = self.api.audit()
            lines = [f"{r['created_at']} | {r['username']} | {r['action']} | مخاطب: {r.get('contact_id') or '-'}" for r in rows]
            QMessageBox.information(self, "گزارش فعالیت (۵۰۰ رویداد اخیر)", "\n".join(lines) if lines else "رویدادی ثبت نشده است.")
        except Exception as exc:
            QMessageBox.warning(self, "خطا", str(exc))

    def logout(self):
        try:
            self.api.logout()
        except Exception:
            pass
        self.api.token = None
        self.close()
        QApplication.quit()

    def selected(self):
        row = self.table.currentRow()
        if row < 0:
            QMessageBox.information(self, "انتخاب مخاطب", "ابتدا مخاطب را انتخاب کنید.")
            return None
        return int(self.table.item(row, 0).data(Qt.ItemDataRole.UserRole))

    def refresh(self, *_):
        try:
            rows = self.api.contacts(self.search.text(), self.category.currentText())
            self.table.setRowCount(0)
            for c in rows:
                idx = self.table.rowCount()
                self.table.insertRow(idx)
                phones = ", ".join(f'{p["phone"]} ({p.get("label","")})' for p in c["phones"])
                values = [c["name"], phones, c["company"], c["email"], c["category"], c["birthday"]]
                for col, value in enumerate(values):
                    item = QTableWidgetItem(str(value))
                    item.setData(Qt.ItemDataRole.UserRole, c["id"])
                    self.table.setItem(idx, col, item)
            self.status.setText(f"{len(rows)} مخاطب | کاربر: {self.api.username} | نقش: {self.api.role}")
        except Exception as exc:
            self.status.setText(f"خطا در دریافت مخاطبان: {exc}")

    def add_contact(self):
        dialog = ContactDialog(self)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        try:
            self.api.add(dialog.values())
            self.refresh()
        except Exception as exc:
            QMessageBox.warning(self, "خطا", str(exc))

    def edit_contact(self):
        cid = self.selected()
        if cid is None:
            return
        try:
            contact = self.api.contact(cid)
            dialog = ContactDialog(self, contact)
            if dialog.exec() == QDialog.DialogCode.Accepted:
                self.api.update(cid, dialog.values())
                self.refresh()
        except Exception as exc:
            QMessageBox.warning(self, "خطا", str(exc))

    def delete_contact(self):
        cid = self.selected()
        if cid is None:
            return
        item = self.table.item(self.table.currentRow(), 0).text()
        answer = QMessageBox.question(self, "تأیید حذف", f"مخاطب «{item}» حذف شود؟",
                                      QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                                      QMessageBox.StandardButton.No)
        if answer != QMessageBox.StandardButton.Yes:
            return
        try:
            self.api.delete(cid)
            self.refresh()
        except Exception as exc:
            QMessageBox.warning(self, "خطا", str(exc))

    def show_reminders(self):
        try:
            rows = self.api.reminders()
            if not rows:
                QMessageBox.information(self, "یادآوری‌ها", "تا ۳۰ روز آینده تولدی ثبت نشده است.")
                return
            lines = []
            for r in rows:
                days = r["days_until"]
                label = "امروز" if days == 0 else ("فردا" if days == 1 else f"{days} روز دیگر")
                lines.append(f'{r["name"]} — {r["birthday"]} — {label}')
            QMessageBox.information(self, "تولدهای پیش رو", "\n".join(lines))
        except Exception as exc:
            QMessageBox.warning(self, "خطا", str(exc))

    def check_reminders_on_start(self):
        try:
            rows = [r for r in self.api.reminders() if r["days_until"] <= 7]
            if rows:
                lines = [f'{r["name"]}: {r["birthday"]} (تا {r["days_until"]} روز)' for r in rows]
                QMessageBox.information(self, "یادآوری تولد", "تولدهای نزدیک:\n" + "\n".join(lines))
        except Exception:
            pass

    def import_file(self):
        path, _ = QFileDialog.getOpenFileName(self, "ورود مخاطبان", "", "Contacts (*.csv *.xlsx *.vcf)")
        if not path:
            return
        try:
            suffix = Path(path).suffix.lower()
            records = []
            if suffix == ".csv":
                with open(path, newline="", encoding="utf-8-sig") as f:
                    records = list(csv.DictReader(f))
            elif suffix == ".xlsx":
                wb = load_workbook(path, read_only=True, data_only=True)
                ws = wb.active
                data = list(ws.iter_rows(values_only=True))
                if data:
                    headers = [str(x or "").strip().lower() for x in data[0]]
                    records = [dict(zip(headers, row)) for row in data[1:]]
            elif suffix == ".vcf":
                records = self.parse_vcf(Path(path).read_text(encoding="utf-8", errors="replace"))
            imported, skipped = 0, 0
            for row in records:
                def get(*keys):
                    lowered = {str(k).strip().lower(): v for k, v in row.items()}
                    for key in keys:
                        if key.lower() in lowered and lowered[key.lower()] is not None:
                            return str(lowered[key.lower()]).strip()
                    return ""
                name = get("name", "نام", "fn", "full name")
                if not name:
                    name = " ".join(filter(None, [get("first name", "given name"), get("last name", "family name")]))
                phone_raw = get("phone", "phones", "شماره", "شماره تلفن", "tel")
                source_phones = row.get("phones", [])
                if not isinstance(source_phones, list):
                    source_phones = []
                if not source_phones and phone_raw:
                    source_phones = [{"phone": line.strip(), "label": "موبایل"}
                                     for line in phone_raw.split(";") if line.strip()]
                if not name or not source_phones:
                    skipped += 1
                    continue
                phones = []
                for phone_item in source_phones:
                    if isinstance(phone_item, dict):
                        number = str(phone_item.get("phone", "")).strip()
                        label = str(phone_item.get("label", "موبایل")).strip() or "موبایل"
                    else:
                        number, label = str(phone_item).strip(), "موبایل"
                    if number:
                        phones.append({"phone": number, "label": label})
                payload = {
                    "name": name, "phones": phones, "email": get("email", "ایمیل"),
                    "company": get("company", "شرکت"), "job_title": get("job", "job title"),
                    "address": get("address", "آدرس"), "category": get("category", "دسته‌بندی") or "عمومی",
                    "birthday": get("birthday", "bday", "تاریخ تولد"), "notes": get("notes", "یادداشت"),
                    "photo_b64": ""
                }
                try:
                    self.api.add(payload)
                    imported += 1
                except Exception:
                    skipped += 1
            self.refresh()
            QMessageBox.information(self, "پایان ورود", f"موفق: {imported}\nردشده/تکراری: {skipped}")
        except Exception as exc:
            QMessageBox.critical(self, "خطای ورود", str(exc))

    @staticmethod
    def parse_vcf(content):
        # vCard permits folded lines; multiple TEL properties must be preserved.
        content = content.replace("\r\n ", "").replace("\n ", "").replace("\r\n\t", "").replace("\n\t", "")
        records = []
        for block in content.split("END:VCARD"):
            if "BEGIN:VCARD" not in block:
                continue
            item = {"phones": []}
            for line in block.splitlines():
                if ":" not in line:
                    continue
                key_part, value = line.split(":", 1)
                key = key_part.split(";", 1)[0].split(".", 1)[0].upper()
                params = key_part.upper()
                value = value.replace("\\n", "\n").replace("\\,", ",").replace("\\;", ";").replace("\\\\", "\\").strip()
                if key == "FN": item["name"] = value
                elif key == "TEL":
                    label = "موبایل"
                    if "HOME" in params: label = "خانه"
                    elif "WORK" in params: label = "کار"
                    elif "CELL" in params: label = "موبایل"
                    item["phones"].append({"phone": value, "label": label})
                elif key == "EMAIL": item.setdefault("email", value)
                elif key == "ORG": item["company"] = value.replace(";", " ")
                elif key == "ADR": item["address"] = value.replace(";", " ")
                elif key == "BDAY":
                    if len(value) == 8 and value.isdigit():
                        value = f"{value[:4]}-{value[4:6]}-{value[6:]}"
                    item["birthday"] = value
                elif key == "NOTE": item["notes"] = value
            if item.get("name") or item.get("phones"):
                records.append(item)
        return records

    def export_file(self):
        path, selected_filter = QFileDialog.getSaveFileName(
            self, "خروجی مخاطبان", str(APP_DIR / "contacts.csv"),
            "CSV (*.csv);;Excel (*.xlsx);;vCard (*.vcf)"
        )
        if not path:
            return
        try:
            rows = self.api.contacts(self.search.text(), self.category.currentText())
            suffix = Path(path).suffix.lower()
            if suffix == ".xlsx":
                wb = Workbook()
                ws = wb.active
                ws.title = "Contacts"
                ws.append(["name", "phones", "email", "company", "job_title", "address",
                           "category", "birthday", "notes"])
                for c in rows:
                    ws.append([c["name"], "; ".join(p["phone"] for p in c["phones"]), c["email"],
                               c["company"], c["job_title"], c["address"], c["category"],
                               c["birthday"], c["notes"]])
                wb.save(path)
            elif suffix == ".vcf":
                with open(path, "w", encoding="utf-8") as f:
                    for c in rows:
                        f.write("BEGIN:VCARD\nVERSION:3.0\n")
                        f.write("FN:" + self.vcf_escape(c["name"]) + "\n")
                        for p in c["phones"]:
                            f.write("TEL;TYPE=" + self.vcf_escape(p["label"]) + ":" + self.vcf_escape(p["phone"]) + "\n")
                        if c["email"]: f.write("EMAIL:" + self.vcf_escape(c["email"]) + "\n")
                        if c["company"]: f.write("ORG:" + self.vcf_escape(c["company"]) + "\n")
                        if c["birthday"]: f.write("BDAY:" + c["birthday"].replace("-", "") + "\n")
                        if c["notes"]: f.write("NOTE:" + self.vcf_escape(c["notes"]) + "\n")
                        f.write("END:VCARD\n")
            else:
                if not path.lower().endswith(".csv"):
                    path += ".csv"
                with open(path, "w", newline="", encoding="utf-8-sig") as f:
                    writer = csv.writer(f)
                    writer.writerow(["name", "phones", "email", "company", "job_title", "address",
                                     "category", "birthday", "notes"])
                    for c in rows:
                        writer.writerow([c["name"], "; ".join(p["phone"] for p in c["phones"]),
                                         c["email"], c["company"], c["job_title"], c["address"],
                                         c["category"], c["birthday"], c["notes"]])
            QMessageBox.information(self, "خروجی", f"فایل ذخیره شد:\n{path}")
        except Exception as exc:
            QMessageBox.critical(self, "خطا در خروجی", str(exc))

    @staticmethod
    def vcf_escape(value):
        return str(value).replace("\\", "\\\\").replace("\n", "\\n").replace(",", "\\,").replace(";", "\\;")

    def backup(self):
        try:
            data = self.api.backup()
            QMessageBox.information(self, "پشتیبان‌گیری", f"نسخه پشتیبان روی سرور ذخیره شد:\n{data['path']}")
        except Exception as exc:
            QMessageBox.warning(self, "خطا", str(exc))


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("Phonebook Advanced")
    login = LoginDialog()
    if login.exec() != QDialog.DialogCode.Accepted:
        return
    api = Api()
    try:
        api.login(login.server.text().strip(), login.username.text().strip(), login.password.text())
    except Exception as exc:
        QMessageBox.critical(None, "ورود ناموفق", str(exc))
        return
    window = MainWindow(api)
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
