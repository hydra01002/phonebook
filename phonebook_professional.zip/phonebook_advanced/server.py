"""
Phonebook Advanced - LAN server
Run on the computer that will host the shared database:
    python server.py
For a trusted LAN demo only. For production, configure HTTPS/reverse proxy and firewall.
"""
import base64
import hashlib
import hmac
import json
import os
import secrets
import sqlite3
import threading
from collections import defaultdict, deque
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from flask import Flask, jsonify, request, g

APP_DIR = Path(__file__).resolve().parent
DATA_DIR = APP_DIR / "data"
DATA_DIR.mkdir(exist_ok=True)
DB_PATH = Path(os.environ.get("PHONEBOOK_DB_PATH", str(DATA_DIR / "contacts.db"))).resolve()
DB_PATH.parent.mkdir(parents=True, exist_ok=True)
HOST = os.environ.get("PHONEBOOK_HOST", "0.0.0.0")
PORT = int(os.environ.get("PHONEBOOK_PORT", "8765"))
BOOTSTRAP_USER = os.environ.get("PHONEBOOK_ADMIN", "admin")
BOOTSTRAP_PASSWORD = os.environ.get("PHONEBOOK_PASSWORD", "")
app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 12 * 1024 * 1024
SESSIONS = {}
SESSION_LOCK = threading.Lock()
LOGIN_ATTEMPTS = defaultdict(deque)
LOGIN_LOCK = threading.Lock()
SESSION_TTL = timedelta(hours=8)
PBKDF2_ROUNDS = 310_000


def db():
    if "db" not in g:
        conn = sqlite3.connect(DB_PATH, timeout=15)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys=ON")
        conn.execute("PRAGMA journal_mode=WAL")
        g.db = conn
    return g.db


@app.teardown_appcontext
def close_db(_error=None):
    conn = g.pop("db", None)
    if conn is not None:
        conn.close()


def hash_password(password, salt=None):
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, PBKDF2_ROUNDS)
    return salt.hex() + "$" + digest.hex()


def verify_password(password, encoded):
    try:
        salt_hex, digest_hex = encoded.split("$", 1)
        salt = bytes.fromhex(salt_hex)
        actual = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, PBKDF2_ROUNDS)
        return hmac.compare_digest(actual.hex(), digest_hex)
    except (ValueError, TypeError):
        return False


def init_db():
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA foreign_keys=ON")
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'user',
        is_active INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS contacts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        name_key TEXT NOT NULL,
        email TEXT NOT NULL DEFAULT '',
        company TEXT NOT NULL DEFAULT '',
        job_title TEXT NOT NULL DEFAULT '',
        address TEXT NOT NULL DEFAULT '',
        category TEXT NOT NULL DEFAULT 'عمومی',
        birthday TEXT NOT NULL DEFAULT '',
        notes TEXT NOT NULL DEFAULT '',
        photo_b64 TEXT NOT NULL DEFAULT '',
        created_by INTEGER,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        FOREIGN KEY(created_by) REFERENCES users(id)
    );
    CREATE INDEX IF NOT EXISTS idx_contacts_name ON contacts(name_key);
    CREATE TABLE IF NOT EXISTS phones (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        contact_id INTEGER NOT NULL,
        phone TEXT NOT NULL,
        label TEXT NOT NULL DEFAULT 'موبایل',
        FOREIGN KEY(contact_id) REFERENCES contacts(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS audit_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL,
        action TEXT NOT NULL,
        contact_id INTEGER,
        created_at TEXT NOT NULL
    );
    """)
    # Safe schema migration for databases created by older versions.
    user_columns = {row[1] for row in conn.execute("PRAGMA table_info(users)")}
    if "is_active" not in user_columns:
        conn.execute("ALTER TABLE users ADD COLUMN is_active INTEGER NOT NULL DEFAULT 1")
    count = conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    if count == 0:
        password = BOOTSTRAP_PASSWORD
        if not password:
            password = secrets.token_urlsafe(12)
            password_file = APP_DIR / "INITIAL_ADMIN_PASSWORD.txt"
            password_file.write_text(
                "Initial admin credentials\n"
                f"Username: {BOOTSTRAP_USER}\nPassword: {password}\n"
                "Change this password after first login and keep this file private.\n",
                encoding="utf-8"
            )
            try:
                password_file.chmod(0o600)
            except OSError:
                pass  # Windows permissions are managed through the file's security settings.
            print(f"\nInitial admin password saved to {password_file}")
        conn.execute("INSERT INTO users(username,password_hash,role,created_at) VALUES(?,?,?,?)",
                     (BOOTSTRAP_USER, hash_password(password), "admin", datetime.now().isoformat(timespec="seconds")))
    conn.commit()
    conn.close()


def current_user():
    header = request.headers.get("Authorization", "")
    token = header[7:] if header.startswith("Bearer ") else ""
    with SESSION_LOCK:
        session = SESSIONS.get(token)
        if not session:
            return None
        if session["expires"] < datetime.now(timezone.utc):
            SESSIONS.pop(token, None)
            return None
        return session


def login_limited(client_ip):
    """Simple per-process throttle. Use a reverse proxy/firewall for stronger protection."""
    now = datetime.now(timezone.utc).timestamp()
    with LOGIN_LOCK:
        attempts = LOGIN_ATTEMPTS[client_ip]
        while attempts and now - attempts[0] > 300:
            attempts.popleft()
        return len(attempts) >= 10


def record_login_failure(client_ip):
    now = datetime.now(timezone.utc).timestamp()
    with LOGIN_LOCK:
        attempts = LOGIN_ATTEMPTS[client_ip]
        while attempts and now - attempts[0] > 300:
            attempts.popleft()
        attempts.append(now)


def require_auth(admin=False):
    user = current_user()
    if not user:
        return None, (jsonify({"error": "ورود لازم است یا نشست منقضی شده است."}), 401)
    if admin and user["role"] != "admin":
        return None, (jsonify({"error": "این عملیات فقط برای مدیر مجاز است."}), 403)
    return user, None


def log_action(username, action, contact_id=None):
    db().execute("INSERT INTO audit_log(username,action,contact_id,created_at) VALUES(?,?,?,?)",
                 (username, action, contact_id, datetime.now().isoformat(timespec="seconds")))
    db().commit()


def clean_contact(payload):
    if not isinstance(payload, dict):
        raise ValueError("داده مخاطب معتبر نیست.")
    name = " ".join(str(payload.get("name", "")).strip().split())
    if not name or len(name) > 120:
        raise ValueError("نام الزامی است و باید حداکثر ۱۲۰ نویسه باشد.")
    birthday = str(payload.get("birthday", "")).strip()
    if birthday:
        try:
            datetime.strptime(birthday, "%Y-%m-%d")
        except ValueError:
            raise ValueError("تاریخ تولد باید به شکل YYYY-MM-DD باشد.")
    phones = payload.get("phones", [])
    if not isinstance(phones, list) or len(phones) > 20:
        raise ValueError("حداکثر ۲۰ شماره برای هر مخاطب مجاز است.")
    clean_phones = []
    for item in phones:
        if not isinstance(item, dict):
            continue
        phone = str(item.get("phone", "")).strip()
        label = str(item.get("label", "موبایل")).strip()[:40] or "موبایل"
        if phone:
            if len(phone) > 50 or not all(c.isdigit() or c in "+()- " for c in phone):
                raise ValueError("فرمت یکی از شماره‌ها معتبر نیست.")
            digits = "".join(c for c in phone if c.isdigit())
            if not 3 <= len(digits) <= 20:
                raise ValueError("طول یکی از شماره‌ها معتبر نیست.")
            clean_phones.append({"phone": phone, "label": label})
    if not clean_phones:
        raise ValueError("حداقل یک شماره تلفن معتبر وارد کنید.")
    photo = str(payload.get("photo_b64", ""))
    if photo:
        if len(photo) > 5_000_000:
            raise ValueError("عکس بیش از حد بزرگ است.")
        try:
            base64.b64decode(photo, validate=True)
        except Exception:
            raise ValueError("داده عکس معتبر نیست.")
    return {
        "name": name, "name_key": name.casefold(), "email": str(payload.get("email", "")).strip()[:254],
        "company": str(payload.get("company", "")).strip()[:150],
        "job_title": str(payload.get("job_title", "")).strip()[:150],
        "address": str(payload.get("address", "")).strip()[:500],
        "category": str(payload.get("category", "عمومی")).strip()[:80] or "عمومی",
        "birthday": birthday, "notes": str(payload.get("notes", "")).strip()[:5000],
        "photo_b64": photo, "phones": clean_phones
    }


def contact_to_dict(row):
    item = dict(row)
    item["phones"] = [dict(p) for p in db().execute(
        "SELECT phone,label FROM phones WHERE contact_id=? ORDER BY id", (item["id"],)
    ).fetchall()]
    return item


@app.get("/api/health")
def health():
    return jsonify({"ok": True, "app": "phonebook-advanced"})


@app.post("/api/login")
def login():
    client_ip = request.remote_addr or "unknown"
    if login_limited(client_ip):
        return jsonify({"error": "تلاش‌های ورود بیش از حد است؛ پنج دقیقه دیگر تلاش کنید."}), 429
    data = request.get_json(silent=True)
    data = data if isinstance(data, dict) else {}
    username = str(data.get("username", "")).strip()
    password = str(data.get("password", ""))
    row = db().execute("SELECT id,username,password_hash,role,is_active FROM users WHERE username=?", (username,)).fetchone()
    if not row or not verify_password(password, row["password_hash"]) or not row["is_active"]:
        record_login_failure(client_ip)
        log_action(username or "unknown", "login_failed")
        return jsonify({"error": "نام کاربری یا رمز عبور اشتباه است، یا حساب غیرفعال شده است."}), 401
    with LOGIN_LOCK:
        LOGIN_ATTEMPTS.pop(client_ip, None)
    token = secrets.token_urlsafe(32)
    with SESSION_LOCK:
        SESSIONS[token] = {"id": row["id"], "username": row["username"], "role": row["role"],
                           "expires": datetime.now(timezone.utc) + SESSION_TTL}
    log_action(row["username"], "login")
    return jsonify({"token": token, "username": row["username"], "role": row["role"],
                    "expires_in": int(SESSION_TTL.total_seconds())})


@app.post("/api/logout")
def logout():
    token = request.headers.get("Authorization", "").removeprefix("Bearer ").strip()
    with SESSION_LOCK:
        session = SESSIONS.pop(token, None)
    if session:
        log_action(session["username"], "logout")
    return jsonify({"ok": True})


@app.post("/api/account/password")
def change_password():
    user, error = require_auth()
    if error: return error
    data = request.get_json(silent=True)
    data = data if isinstance(data, dict) else {}
    old_password = str(data.get("old_password", ""))
    new_password = str(data.get("new_password", ""))
    row = db().execute("SELECT password_hash FROM users WHERE id=? AND is_active=1", (user["id"],)).fetchone()
    if not row or not verify_password(old_password, row["password_hash"]):
        return jsonify({"error": "رمز فعلی اشتباه است."}), 400
    if len(new_password) < 12 or new_password.isspace():
        return jsonify({"error": "رمز جدید باید حداقل ۱۲ نویسه داشته باشد."}), 400
    db().execute("UPDATE users SET password_hash=? WHERE id=?", (hash_password(new_password), user["id"]))
    db().commit()
    # Revoke all sessions belonging to this account; the user must log in again.
    with SESSION_LOCK:
        for token, session in list(SESSIONS.items()):
            if session["id"] == user["id"]:
                SESSIONS.pop(token, None)
    log_action(user["username"], "change_password")
    return jsonify({"ok": True, "message": "رمز تغییر کرد؛ لطفاً دوباره وارد شوید."})


@app.get("/api/contacts")
def list_contacts():
    user, error = require_auth()
    if error: return error
    query = request.args.get("q", "").strip()
    category = request.args.get("category", "").strip()
    sql = "SELECT * FROM contacts WHERE 1=1"
    args = []
    if query:
        pattern = f"%{query}%"
        sql += " AND (name LIKE ? OR email LIKE ? OR company LIKE ? OR notes LIKE ? OR id IN (SELECT contact_id FROM phones WHERE phone LIKE ?))"
        args.extend([pattern, pattern, pattern, pattern, pattern])
    if category and category != "همه":
        sql += " AND category=?"
        args.append(category)
    sql += " ORDER BY name COLLATE NOCASE"
    rows = db().execute(sql, args).fetchall()
    result = []
    for row in rows:
        item = contact_to_dict(row)
        # Keep list/search responses small; photo data is fetched only for a single contact.
        item.pop("photo_b64", None)
        result.append(item)
    return jsonify(result)


@app.get("/api/contacts/<int:contact_id>")
def get_contact(contact_id):
    user, error = require_auth()
    if error: return error
    row = db().execute("SELECT * FROM contacts WHERE id=?", (contact_id,)).fetchone()
    if not row:
        return jsonify({"error": "مخاطب پیدا نشد."}), 404
    return jsonify(contact_to_dict(row))


@app.post("/api/contacts")
def create_contact():
    user, error = require_auth()
    if error: return error
    try:
        item = clean_contact(request.get_json(silent=True) or {})
        now = datetime.now().isoformat(timespec="seconds")
        cur = db().execute("""
            INSERT INTO contacts(name,name_key,email,company,job_title,address,category,birthday,notes,photo_b64,created_by,created_at,updated_at)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (item["name"], item["name_key"], item["email"], item["company"], item["job_title"],
              item["address"], item["category"], item["birthday"], item["notes"], item["photo_b64"],
              user["id"], now, now))
        cid = cur.lastrowid
        db().executemany("INSERT INTO phones(contact_id,phone,label) VALUES(?,?,?)",
                         [(cid, p["phone"], p["label"]) for p in item["phones"]])
        db().commit()
        log_action(user["username"], "create", cid)
        return jsonify({"id": cid}), 201
    except ValueError as exc:
        db().rollback()
        return jsonify({"error": str(exc)}), 400
    except sqlite3.IntegrityError:
        db().rollback()
        return jsonify({"error": "مخاطبی با این نام وجود دارد."}), 409


@app.put("/api/contacts/<int:contact_id>")
def update_contact(contact_id):
    user, error = require_auth()
    if error: return error
    try:
        item = clean_contact(request.get_json(silent=True) or {})
        now = datetime.now().isoformat(timespec="seconds")
        cur = db().execute("""
            UPDATE contacts SET name=?,name_key=?,email=?,company=?,job_title=?,address=?,category=?,birthday=?,notes=?,photo_b64=?,updated_at=?
            WHERE id=?
        """, (item["name"], item["name_key"], item["email"], item["company"], item["job_title"],
              item["address"], item["category"], item["birthday"], item["notes"], item["photo_b64"], now, contact_id))
        if cur.rowcount == 0:
            db().rollback()
            return jsonify({"error": "مخاطب پیدا نشد."}), 404
        db().execute("DELETE FROM phones WHERE contact_id=?", (contact_id,))
        db().executemany("INSERT INTO phones(contact_id,phone,label) VALUES(?,?,?)",
                         [(contact_id, p["phone"], p["label"]) for p in item["phones"]])
        db().commit()
        log_action(user["username"], "update", contact_id)
        return jsonify({"ok": True})
    except ValueError as exc:
        db().rollback()
        return jsonify({"error": str(exc)}), 400
    except sqlite3.IntegrityError:
        db().rollback()
        return jsonify({"error": "نام مخاطب تکراری است."}), 409


@app.delete("/api/contacts/<int:contact_id>")
def delete_contact(contact_id):
    user, error = require_auth()
    if error: return error
    cur = db().execute("DELETE FROM contacts WHERE id=?", (contact_id,))
    if cur.rowcount == 0:
        db().rollback()
        return jsonify({"error": "مخاطب پیدا نشد."}), 404
    db().commit()
    log_action(user["username"], "delete", contact_id)
    return jsonify({"ok": True})


@app.get("/api/reminders")
def reminders():
    user, error = require_auth()
    if error: return error
    today = datetime.now().date()
    rows = db().execute("SELECT * FROM contacts WHERE birthday != ''").fetchall()
    result = []
    for row in rows:
        try:
            birthday = datetime.strptime(row["birthday"], "%Y-%m-%d").date()
            try:
                next_date = birthday.replace(year=today.year)
            except ValueError:  # February 29 in a non-leap year
                next_date = date(today.year, 2, 28)
            if next_date < today:
                try:
                    next_date = birthday.replace(year=today.year + 1)
                except ValueError:
                    next_date = date(today.year + 1, 2, 28)
            days = (next_date - today).days
            if days <= 30:
                result.append({"id": row["id"], "name": row["name"], "birthday": row["birthday"], "days_until": days})
        except ValueError:
            continue
    return jsonify(sorted(result, key=lambda x: x["days_until"]))


@app.post("/api/admin/users")
def create_user():
    admin, error = require_auth(admin=True)
    if error: return error
    data = request.get_json(silent=True)
    data = data if isinstance(data, dict) else {}
    username = str(data.get("username", "")).strip()
    password = str(data.get("password", ""))
    role = str(data.get("role", "user"))
    if not 3 <= len(username) <= 40 or not username.replace("_", "").replace("-", "").isalnum():
        return jsonify({"error": "نام کاربری باید ۳ تا ۴۰ نویسه و فقط شامل حروف، عدد، _ یا - باشد."}), 400
    if len(password) < 12:
        return jsonify({"error": "رمز عبور باید حداقل ۱۲ نویسه باشد."}), 400
    if role not in ("admin", "user"):
        return jsonify({"error": "نقش نامعتبر است."}), 400
    try:
        db().execute("INSERT INTO users(username,password_hash,role,is_active,created_at) VALUES(?,?,?,?,?)",
                     (username, hash_password(password), role, 1, datetime.now().isoformat(timespec="seconds")))
        db().commit()
        log_action(admin["username"], "create_user")
        return jsonify({"ok": True}), 201
    except sqlite3.IntegrityError:
        db().rollback()
        return jsonify({"error": "این نام کاربری قبلاً استفاده شده است."}), 409


@app.get("/api/admin/users")
def list_users():
    admin, error = require_auth(admin=True)
    if error: return error
    rows = db().execute("SELECT id,username,role,is_active,created_at FROM users ORDER BY username COLLATE NOCASE").fetchall()
    return jsonify([dict(row) for row in rows])


@app.patch("/api/admin/users/<int:user_id>")
def update_user_status():
    admin, error = require_auth(admin=True)
    if error: return error
    data = request.get_json(silent=True)
    data = data if isinstance(data, dict) else {}
    active = data.get("is_active")
    if not isinstance(active, bool):
        return jsonify({"error": "مقدار is_active باید true یا false باشد."}), 400
    if user_id == admin["id"] and not active:
        return jsonify({"error": "مدیر نمی‌تواند حساب خودش را غیرفعال کند."}), 400
    cur = db().execute("UPDATE users SET is_active=? WHERE id=?", (1 if active else 0, user_id))
    if cur.rowcount == 0:
        db().rollback()
        return jsonify({"error": "کاربر پیدا نشد."}), 404
    db().commit()
    if not active:
        with SESSION_LOCK:
            for token, session in list(SESSIONS.items()):
                if session["id"] == user_id:
                    SESSIONS.pop(token, None)
    log_action(admin["username"], "activate_user" if active else "deactivate_user")
    return jsonify({"ok": True})


@app.get("/api/admin/audit")
def audit():
    admin, error = require_auth(admin=True)
    if error: return error
    rows = db().execute("SELECT username,action,contact_id,created_at FROM audit_log ORDER BY id DESC LIMIT 500").fetchall()
    return jsonify([dict(r) for r in rows])


@app.get("/api/admin/backup")
def backup():
    admin, error = require_auth(admin=True)
    if error: return error
    # SQLite online backup API; file is written on the server.
    target = DB_PATH.parent / f"backup_{datetime.now():%Y%m%d_%H%M%S}.db"
    dest = sqlite3.connect(target)
    try:
        db().backup(dest)
    finally:
        dest.close()
    return jsonify({"ok": True, "path": str(target.name)})


if __name__ == "__main__":
    init_db()
    print(f"Phonebook server listening on http://{HOST}:{PORT}")
    print("WARNING: HTTP does not encrypt passwords or contact data. Use only on a trusted LAN/VPN until HTTPS is configured.")
    print("Allow the port only on the private network; never expose this development server directly to the public internet.")
    app.run(host=HOST, port=PORT, debug=False, threaded=True)
