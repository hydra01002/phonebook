"""Basic API regression tests. Run with: python -m unittest discover -s tests -v"""
import tempfile
import unittest
from pathlib import Path

import server


class PhonebookApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp_dir = tempfile.TemporaryDirectory(prefix="phonebook-tests-")
        server.DB_PATH = Path(cls.temp_dir.name) / "test_contacts.db"
        server.BOOTSTRAP_USER = "admin"
        server.BOOTSTRAP_PASSWORD = "Test-Admin-Password-123!"

    @classmethod
    def tearDownClass(cls):
        cls.temp_dir.cleanup()

    def setUp(self):
        if server.DB_PATH.exists():
            server.DB_PATH.unlink()
        for suffix in ("-wal", "-shm"):
            extra = Path(str(server.DB_PATH) + suffix)
            if extra.exists():
                extra.unlink()
        with server.SESSION_LOCK:
            server.SESSIONS.clear()
        with server.LOGIN_LOCK:
            server.LOGIN_ATTEMPTS.clear()
        server.init_db()
        self.client = server.app.test_client()
        response = self.client.post("/api/login", json={
            "username": "admin", "password": "Test-Admin-Password-123!"
        })
        self.assertEqual(response.status_code, 200)
        self.token = response.get_json()["token"]
        self.headers = {"Authorization": f"Bearer {self.token}"}

    def test_health_endpoint(self):
        response = self.client.get("/api/health")
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.get_json()["ok"])

    def test_create_and_search_contact(self):
        response = self.client.post("/api/contacts", headers=self.headers, json={
            "name": "Test Contact", "phones": [{"phone": "+123456789", "label": "work"}],
            "email": "test@example.com", "category": "کار"
        })
        self.assertEqual(response.status_code, 201)
        results = self.client.get("/api/contacts?q=Test", headers=self.headers)
        self.assertEqual(results.status_code, 200)
        self.assertEqual(results.get_json()[0]["name"], "Test Contact")
        self.assertEqual(len(results.get_json()[0]["phones"]), 1)

    def test_contact_requires_valid_phone(self):
        response = self.client.post("/api/contacts", headers=self.headers, json={
            "name": "No Phone", "phones": []
        })
        self.assertEqual(response.status_code, 400)

    def test_user_management_is_admin_only(self):
        response = self.client.post("/api/admin/users", headers=self.headers, json={
            "username": "ordinary_user", "password": "Another-Password-123!", "role": "user"
        })
        self.assertEqual(response.status_code, 201)
        users = self.client.get("/api/admin/users", headers=self.headers)
        self.assertEqual(users.status_code, 200)
        self.assertGreaterEqual(len(users.get_json()), 2)

    def test_change_password_revokes_old_session(self):
        response = self.client.post("/api/account/password", headers=self.headers, json={
            "old_password": "Test-Admin-Password-123!",
            "new_password": "New-Admin-Password-456!"
        })
        self.assertEqual(response.status_code, 200)
        old_session = self.client.get("/api/contacts", headers=self.headers)
        self.assertEqual(old_session.status_code, 401)
        new_login = self.client.post("/api/login", json={
            "username": "admin", "password": "New-Admin-Password-456!"
        })
        self.assertEqual(new_login.status_code, 200)


if __name__ == "__main__":
    unittest.main()
