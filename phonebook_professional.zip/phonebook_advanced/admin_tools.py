"""Utility to create a user through the running server as an admin."""
import getpass
import requests


def main():
    base = input("Server URL [http://127.0.0.1:8765]: ").strip() or "http://127.0.0.1:8765"
    username = input("Admin username: ").strip()
    password = getpass.getpass("Admin password: ")
    new_username = input("New username: ").strip()
    new_password = getpass.getpass("New user's password (12+ chars): ")
    role = input("Role [user/admin]: ").strip().lower() or "user"
    session = requests.Session()
    response = session.post(base.rstrip("/") + "/api/login",
                            json={"username": username, "password": password}, timeout=15)
    if not response.ok:
        raise SystemExit("Admin login failed: " + response.text)
    token = response.json()["token"]
    response = session.post(base.rstrip("/") + "/api/admin/users",
                            headers={"Authorization": "Bearer " + token},
                            json={"username": new_username, "password": new_password, "role": role},
                            timeout=15)
    if not response.ok:
        raise SystemExit("User creation failed: " + response.text)
    print("User created successfully.")


if __name__ == "__main__":
    main()
